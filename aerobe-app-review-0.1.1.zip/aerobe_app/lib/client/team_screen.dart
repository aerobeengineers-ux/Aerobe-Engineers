import 'package:flutter/material.dart';

import '../api.dart';
import '../config.dart';
import '../shared/employee_profile_screen.dart';
import '../shared/widgets.dart';

class TeamScreen extends StatefulWidget {
  const TeamScreen({super.key});

  @override
  State<TeamScreen> createState() => _TeamScreenState();
}

class _TeamScreenState extends State<TeamScreen> {
  late Future<List<dynamic>> _team;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    _team = Api.get('/team').then((d) => (d as Map<String, dynamic>)['team'] as List<dynamic>);
  }

  Future<void> _refresh() async {
    setState(_load);
    await _team;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My team')),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<List<dynamic>>(
          future: _team,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) return const LoadingView();
            if (snap.hasError) return ErrorView(message: snap.error.toString(), onRetry: _refresh);
            final team = snap.data!;
            if (team.isEmpty) {
              return const EmptyView(text: 'Your specialists will appear here once they are assigned to your jobs.');
            }
            return ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: team.length,
              itemBuilder: (context, i) {
                final t = team[i] as Map<String, dynamic>;
                final rating = t['rating'] as Map<String, dynamic>;
                final chats = (t['chats'] as List).cast<Map<String, dynamic>>();
                final active = chats.where((c) => c['active'] == true).toList();
                return Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(12),
                    leading: CircleAvatar(
                      backgroundImage: NetworkImage(Api.photoUrl(t['employee_id'] as int), headers: Api.authHeaders),
                      onBackgroundImageError: (_, __) {},
                      child: Text((t['name'] as String).substring(0, 1)),
                    ),
                    title: Text(t['name'] as String),
                    subtitle: Text([
                      if ((t['headline'] as String?)?.isNotEmpty ?? false) t['headline'],
                      rating['count'] == 0 ? 'Not rated yet' : '★ ${rating['average']} (${rating['count']})',
                    ].join('\n')),
                    isThreeLine: true,
                    onTap: () => Navigator.push(context, MaterialPageRoute(
                      builder: (_) => EmployeeProfileScreen(
                        employeeId: t['employee_id'] as int,
                        chatAssignmentId: active.isEmpty ? null : active.first['assignment_id'] as int,
                      ),
                    )),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
