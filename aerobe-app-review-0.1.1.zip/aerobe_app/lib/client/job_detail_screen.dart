import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../api.dart';
import '../config.dart';
import '../shared/chat_screen.dart';
import '../shared/employee_profile_screen.dart';
import '../shared/widgets.dart';

class JobDetailScreen extends StatefulWidget {
  const JobDetailScreen({super.key, required this.jobId});
  final int jobId;

  @override
  State<JobDetailScreen> createState() => _JobDetailScreenState();
}

class _JobDetailScreenState extends State<JobDetailScreen> {
  late Future<Map<String, dynamic>> _job;
  bool _uploading = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    _job = Api.get('/jobs/${widget.jobId}').then((d) => (d as Map<String, dynamic>)['job'] as Map<String, dynamic>);
  }

  Future<void> _refresh() async {
    setState(_load);
    await _job;
  }

  Future<void> _addScreenshot() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600);
    if (picked == null) return;
    setState(() => _uploading = true);
    try {
      final bytes = await picked.readAsBytes();
      await Api.upload('/jobs/${widget.jobId}/files', 'file', bytes, picked.name);
      await _refresh();
    } on ApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Job')),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<Map<String, dynamic>>(
          future: _job,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) return const LoadingView();
            if (snap.hasError) return ErrorView(message: snap.error.toString(), onRetry: _refresh);
            final j = snap.data!;
            final files = (j['files'] as List).cast<Map<String, dynamic>>();
            final assignments = (j['assignments'] as List).cast<Map<String, dynamic>>();
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(j['title'] as String, style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 4),
                Text('Status: ${j['status']}'),
                const SizedBox(height: 12),
                Text(j['description'] as String),
                const SizedBox(height: 12),
                Text('Budget: ${j['budget_amount'] ?? 'not stated'} ${j['budget_currency'] ?? ''}'),
                Text('Time frame: ${j['timeframe'] ?? 'not stated'}'),
                if (j['reference_url'] != null) Text('Reference: ${j['reference_url']}'),
                const SizedBox(height: 20),
                Text('Screenshots', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                if (files.isNotEmpty)
                  SizedBox(
                    height: 120,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: files.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (context, i) => ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          '$apiBase/job-files/${files[i]['id']}',
                          headers: Api.authHeaders,
                          width: 160,
                          height: 120,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const SizedBox(
                              width: 160, child: Center(child: Icon(Icons.broken_image))),
                        ),
                      ),
                    ),
                  ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  icon: _uploading
                      ? const SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.add_photo_alternate_outlined),
                  label: const Text('Add screenshot'),
                  onPressed: _uploading || files.length >= 5 ? null : _addScreenshot,
                ),
                const SizedBox(height: 20),
                Text('Specialists', style: Theme.of(context).textTheme.titleMedium),
                if (assignments.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text("No one is assigned yet. We'll be in touch once the team has reviewed your job."),
                  ),
                for (final a in assignments)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const CircleAvatar(child: Icon(Icons.person_outline)),
                    title: Text(a['employee_name'] as String),
                    subtitle: Text(a['active'] == true ? 'Active' : 'Ended'),
                    trailing: const Icon(Icons.chat_bubble_outline),
                    onTap: () => Navigator.push(context, MaterialPageRoute(
                      builder: (_) => ChatScreen(
                          assignmentId: a['assignment_id'] as int, title: a['employee_name'] as String),
                    )),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
