import 'package:flutter/material.dart';

import '../api.dart';

class PostJobScreen extends StatefulWidget {
  const PostJobScreen({super.key});

  @override
  State<PostJobScreen> createState() => _PostJobScreenState();
}

class _PostJobScreenState extends State<PostJobScreen> {
  final _title = TextEditingController();
  final _description = TextEditingController();
  final _budget = TextEditingController();
  final _timeframe = TextEditingController();
  final _reference = TextEditingController();
  String _currency = 'USD';
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_title, _description, _budget, _timeframe, _reference]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() => _busy = true);
    try {
      await Api.post('/jobs', {
        'title': _title.text.trim(),
        'description': _description.text.trim(),
        'budget': _budget.text.trim(),
        'budget_currency': _currency,
        'timeframe': _timeframe.text.trim(),
        'reference_url': _reference.text.trim(),
      });
      if (mounted) Navigator.pop(context, true);
    } on ApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Post a job')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(controller: _title, maxLength: 120,
              decoration: const InputDecoration(labelText: 'Job title')),
          const SizedBox(height: 12),
          TextField(controller: _description, maxLines: 6, maxLength: 4000,
              decoration: const InputDecoration(labelText: 'Job details', alignLabelWithHint: true)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _budget,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Budget (optional)'),
              ),
            ),
            const SizedBox(width: 12),
            DropdownButton<String>(
              value: _currency,
              items: const [
                DropdownMenuItem(value: 'USD', child: Text('USD')),
                DropdownMenuItem(value: 'INR', child: Text('INR')),
              ],
              onChanged: (v) => setState(() => _currency = v ?? 'USD'),
            ),
          ]),
          const SizedBox(height: 12),
          TextField(controller: _timeframe, maxLength: 100,
              decoration: const InputDecoration(labelText: 'Time frame (optional)', hintText: 'e.g. 2 weeks')),
          const SizedBox(height: 12),
          TextField(controller: _reference, keyboardType: TextInputType.url,
              decoration: const InputDecoration(labelText: 'Reference link (optional)', hintText: 'https://')),
          const SizedBox(height: 8),
          const Text('You can add screenshots after the job is posted.', style: TextStyle(fontSize: 12)),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _busy ? null : _submit,
            child: _busy
                ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Post job'),
          ),
        ],
      ),
    );
  }
}
