import 'package:flutter/material.dart';

import '../api.dart';
import '../shared/widgets.dart';
import 'job_detail_screen.dart';
import 'post_job_screen.dart';

class JobsScreen extends StatefulWidget {
  const JobsScreen({super.key});

  @override
  State<JobsScreen> createState() => _JobsScreenState();
}

class _JobsScreenState extends State<JobsScreen> {
  late Future<List<dynamic>> _jobs;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    _jobs = Api.get('/jobs').then((d) => (d as Map<String, dynamic>)['jobs'] as List<dynamic>);
  }

  Future<void> _refresh() async {
    setState(_load);
    await _jobs;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My jobs')),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text('Post a job'),
        onPressed: () async {
          final posted = await Navigator.push<bool>(
              context, MaterialPageRoute(builder: (_) => const PostJobScreen()));
          if (posted == true) _refresh();
        },
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<List<dynamic>>(
          future: _jobs,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) return const LoadingView();
            if (snap.hasError) return ErrorView(message: snap.error.toString(), onRetry: _refresh);
            final jobs = snap.data!;
            if (jobs.isEmpty) {
              return const EmptyView(text: 'No jobs yet. Post one with your budget, time frame and screenshots, '
                  'and we will match you with a specialist.');
            }
            return ListView.separated(
              padding: const EdgeInsets.only(bottom: 90),
              itemCount: jobs.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final j = jobs[i] as Map<String, dynamic>;
                return ListTile(
                  title: Text(j['title'] as String),
                  subtitle: Text('${j['status']} · ${j['timeframe'] ?? 'No time frame'}'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.push(context, MaterialPageRoute(
                      builder: (_) => JobDetailScreen(jobId: j['id'] as int))),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
